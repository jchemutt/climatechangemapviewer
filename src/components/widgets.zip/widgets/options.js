import unit from "@/data/units.json";

export default {
  unit,
};
