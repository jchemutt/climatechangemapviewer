export const tonsToTonnes = (value) => value * 0.907185;
