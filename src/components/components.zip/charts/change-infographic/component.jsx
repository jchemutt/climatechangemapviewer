import React, { PureComponent } from "react";

class ChangeInfographic extends PureComponent {
  render() {
    return <div>Hello Change Chart</div>;
  }
}

export default ChangeInfographic;
