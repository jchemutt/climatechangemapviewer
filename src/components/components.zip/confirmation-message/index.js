import PageComponent from './component';

export default PageComponent;
