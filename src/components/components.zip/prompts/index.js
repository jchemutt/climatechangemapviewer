import component from './component';

export default component;
