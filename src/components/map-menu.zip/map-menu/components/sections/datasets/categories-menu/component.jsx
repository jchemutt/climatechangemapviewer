import React from "react";

import "./styles.scss";

const CategoriesMenu = () => {
  return null; // ❌ Remove category selection (only one fixed category is used)
};

export default CategoriesMenu;
